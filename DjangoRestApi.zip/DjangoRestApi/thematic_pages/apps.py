from django.apps import AppConfig


class ThematicPagesConfig(AppConfig):
    name = 'thematic_pages'
