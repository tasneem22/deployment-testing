from django.contrib import admin
from .models import ThematicPage

# Register ThematicPage model in admin panel
admin.site.register(ThematicPage)
