from django.apps import AppConfig


class ModeratorsViewConfig(AppConfig):
    name = 'moderators_view'
