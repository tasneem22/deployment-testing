from django.apps import AppConfig


class UsersViewConfig(AppConfig):
    name = 'users_view'
